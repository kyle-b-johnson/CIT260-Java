public class W1dot1
{
    public static void main(String[] args)
    {
        String name = "Kyle Johnson";
        String course = "CIT260-XX";
        String homeTown = "Fayetteville, Arkansas";
        String dessert = "Tiramisu";
        System.out.println(name);
        System.out.println(course);
        System.out.println(homeTown);
        System.out.println(dessert);
        /* System.out.println( "Kyle Johnson" );
        System.out.println( "CIT260-XX" );
        System.out.println( "Fayetteville, Arkansas");
        System.out.println( "Tiramisu" ); */
    }
}